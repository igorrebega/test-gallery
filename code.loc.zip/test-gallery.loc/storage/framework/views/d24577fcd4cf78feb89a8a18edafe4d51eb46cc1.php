<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Galleries</div>

                    <div class="panel-body">
                        <p>
                            <a href="/gallery/create" class="btn btn-success">Create gallery</a>
                        </p>
                        <?php if(empty($galleries)): ?>
                            <p class="alert alert-info">There is no galleries create, please make one</p>
                        <?php else: ?>
                            <table class="table">
                                <thead>
                                <tr>
                                    <td>Cover</td>
                                    <td>Title</td>
                                    <td></td>
                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php if($gallery['cover']): ?>
                                                <img src="/images/<?php echo e($id); ?>/<?php echo e($gallery['cover']); ?>" height="50"
                                                     width="50">
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('gallery.edit',['id'=>$id])); ?>"><?php echo e($gallery['title']); ?></a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('gallery.delete',['id' => $id])); ?>" class="btn btn-danger">
                                                Delete
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>