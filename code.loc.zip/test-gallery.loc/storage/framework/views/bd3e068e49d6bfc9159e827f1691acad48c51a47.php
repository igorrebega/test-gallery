<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Edit gallery <?php echo e($model['title']); ?></div>

                    <div class="panel-body">
                        <form class="form-horizontal" method="POST" action="<?php echo e(route('gallery.update',['id'=>$id])); ?>">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label for="title" class="col-md-4 control-label">Title</label>

                                <div class="col-md-6">
                                    <input id="title" name="title" type="text" class="form-control" title="title"
                                           value="<?php echo e(old('title') ?: $model['title']); ?>" required
                                           autofocus>

                                    <?php if($errors->has('title')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                        Update
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-heading">Upload photos</div>

                    <div class="panel-body">
                        <form class="form-horizontal"
                              method="POST"
                              action="<?php echo e(route('photo.upload')); ?>"
                              enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>



                            <input type="hidden" name="id" value="<?php echo e($id); ?>">
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label for="filename" class="col-md-4 control-label">Photos</label>

                                <div class="col-md-6">
                                    <input id="filename" type="file" name="filename[]"
                                           class="form-control"
                                           multiple
                                           accept="image/png, image/jpeg">

                                    <?php if($errors->has('filename.*')): ?>
                                        <span class="help-block">
                                        <strong>Photos must be in .png or .jpg format with max size 2048kb</strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-success">
                                        Upload
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <?php if(!empty($photos)): ?>
                    <div class="panel panel-default">
                        <div class="panel-heading">Manage photos</div>

                        <div class="panel-body">

                            <table class="table">
                                <thead>
                                <tr>
                                    <td>Thumbnail</td>
                                    <td>Title</td>
                                    <td></td>
                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photoId => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e('/images/'.$id.'/'.$photo['name']); ?>">
                                                <img width="50" height="50"
                                                     src="<?php echo e('/images/'.$id.'/'.$photo['name']); ?>">
                                            </a>
                                        </td>
                                        <td>
                                            <?php if($photo['isPrimary']): ?>
                                                <button class="btn btn-info" disabled>
                                                    Is cover
                                                </button>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('photo.makeCover',['galleryId' => $id, 'id' => $photoId])); ?>"
                                                   class="btn btn-success">
                                                    Make cover
                                                </a>
                                            <?php endif; ?>

                                            <a href="<?php echo e(route('photo.delete',['galleryId' => $id, 'id' => $photoId])); ?>"
                                               class="btn btn-danger">
                                                Delete
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>