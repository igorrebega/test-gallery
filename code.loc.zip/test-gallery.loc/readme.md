## Test gallery task

This is test gallery task. 

- First of all make ``composer install``
- After that you can run server by ``php artisan serve``